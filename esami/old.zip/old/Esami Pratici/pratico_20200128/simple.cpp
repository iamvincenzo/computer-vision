//OpneCV
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

//std:
#include <fstream>
#include <iostream>
#include <string>

//#define USE_OPENCVVIZ
#ifdef USE_OPENCVVIZ
#include <opencv2/viz.hpp>

void PointsToMat(const std::vector< cv::Point3f >& points, cv::Mat& mat)
{
	mat = cv::Mat(1, 3*points.size(), CV_32FC3);
	for (unsigned int i=0,j = 0; i < points.size(); ++i, j+=3)
	{
		mat.at<float>(j) = points[i].x;
		mat.at<float>(j+1) = points[i].y;
		mat.at<float>(j+2) = points[i].z;
	}
}
#endif

struct points3D {
   float x;
	 float y;
	 float z;
} mypoints;

/*
 * Piano passante per tre punti:
 *
 * https://en.wikipedia.org/wiki/Plane_(geometry)
 *
 * Equazione del piano usata: ax + by +cz + d = 0
 */
//
// DO NOT TOUCH
void plane3points(cv::Point3f p1, cv::Point3f p2, cv::Point3f p3, float & a, float & b, float & c ,float & d)
{
	cv::Point3f p21 = p2-p1;
	cv::Point3f p31 = p3-p1;

	a = p21.y*p31.z - p21.z*p31.y;
	b = p21.x*p31.z - p21.z*p31.x;
	c = p21.x*p31.y - p21.y*p31.x;

	d = -(a*p1.x + b*p1.y + c*p1.z);
}

/*
 * Distanza punto piano.
 *
 * https://en.wikipedia.org/wiki/Plane_(geometry)
 */
//
// DO NOT TOUCH
float distance_plane_point(cv::Point3f p, float a, float b, float c ,float d)
{
	return fabs((a*p.x + b*p.y + c*p.z +d))/(sqrt(a*a + b*b + c*c ));
}


/////////////////////////////////////////////////////////////////////
//	EX1
//
//	 Calcolare le coordinate 3D x,y,z per ogni pixel, nota la disparita'
//
//	 Si vedano le corrispondenti formule per il calcolo (riga, colonna, disparita') -> (x,y,z)
//
//	 Utilizzare i parametri di calibrazione forniti
//
//	 I valori di disparita' sono contenuti nell'immagine disp
void compute3Dpoints(const cv::Mat &disp, std::vector<cv::Point3f> &points, std::vector<cv::Point2i> &rc)
{
	//parametri di calibrazione predefini
	// DO NOT TOUCH
	constexpr float focal = 657.475;
	constexpr float baseline = 0.3;
	constexpr float u0 = 509.5;
	constexpr float v0 = 247.15;

	// write the structure to the file .dat,
	//NOTA: IL FILE VIENE SALVATO IN BUILD
	std::ofstream out;
	out.open("mypoints.dat"); // opens the file

	for(int r=0;r<disp.rows;++r)
	{
		for(int c=0;c<disp.cols;++c)
		{
			if(disp.at<float>(r,c)>1)
			{
				float x,y,z;

				/*
				 * YOUR CODE HERE
				 *
				 * calcolare le coordinate x,y,z a partire dalla disparita' e da riga/colonna
				 */
				 x = ((r-u0)*baseline) / (disp.at<float>(r,c));
				 //std::cout << "X: " << x << '\n';
				 y = ((c-v0)*baseline) / (disp.at<float>(r,c));
				 //std::cout << "Y: " << y << '\n';
				 z = (baseline*focal) / (disp.at<float>(r,c));
				 //std::cout << "Z: " << z << '\n';

				/*
				 *
				 */

				// salvo tutti i punti 3D con z entro i 30m, per semplicita'
				if(z<30)
				{
					points.push_back(cv::Point3f(x,y,z));
					//std::cout << "points: "  << points << '\n';
					rc.push_back(cv::Point2i(r,c));
					//std::cout << "rc: " << rc << '\n';

					//std::cout << "Scrivo su file i punti." << '\n';
					//out << x << " " << y << " " << z << std::endl;
				}
			}
		}
	}
}
//////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////
//	 EX. 2
//
//	 Calcolare con RANSAC il piano che meglio modella i punti forniti
//
//	 Si tratta di implementare un plane fitting con RANSAC:
//
//	 1) scelgo a caso 3 punti da points
//	 2) calcolo il piano con la funzione fornita
//	 3) calcolo la distanza di tutti i punto dal piano, con la funzione fornita
//   4) calcolo gli inliers del modello attuale, salvando punti e coordinate immagine corrispondenti
//
//	 Mi devo salvare il modello che ha piu' inliers
//
//	 Una volta ottenuto il piano, generare un'immagine dei soli inliers
void computePlane(const std::vector<cv::Point3f> &points, const std::vector<cv::Point2i> &uv,
		std::vector<cv::Point3f> &inliers_best_points, std::vector<cv::Point2i> &inliers_best_uv)
{
	// Parametri di RANSAC:
	int N = 10000; // numero di iterazioni
	float epsilon = 0.2; //errore massimo di un inliers

	std::cout<<"RANSAC"<<std::endl;
	std::cout<<"Points: "<<points.size()<<std::endl;
	std::cout<<"UV: "<< uv.size() << std::endl;

	std::vector<cv::Point3f> randomPoints(3);
	float a, b, c, d;
	int bestIteration = 0;
	int bestInliers = 0;
	int inliers;
	std::vector<int> cii; //Current Iteration Inliers

	/*
	 * YOUR CODE HERE
	 *
	 * Ciclo di RANSAC
	 */
	 for(int n = 0; n < 200 ; n++)
	 {
		 inliers = 0;
		 cii.clear();

//	 1) scelgo a caso 3 punti da points
		 for(int i = 0 ; i < 3 ;i++) //Generazione H
		 {
		 	int random_index = rand()%points.size();
		 	randomPoints[i] = points[random_index];
		 	//std::cout << "randomPoints[i]" << randomPoints[i] << '\n';
			//std::cout << "points[random_index]" << points[random_index] << '\n';
		 }

//	 2) calcolo il piano con la funzione fornita
		 //std::cout << "Calcolo piano. " << '\n';
		 plane3points(randomPoints[0], randomPoints[1], randomPoints[2], a , b, c, d);
		 //std::cout << "a: "<< a << "b: "<< b <<  "c: "<<c << "d: "<< d << '\n';

//	 3) calcolo la distanza di tutti i punto dal piano, con la funzione fornita

		 for(int j = 0; j< points.size(); j++)
		 {
			 //std::cout << "Calcolo distanza. " << '\n';
			 //distance_plane_point(points[j], a, b, c, d);

			 if( distance_plane_point(points[j], a, b, c, d) < epsilon )
       {
         //std::cout << "Distanza: " << distance << " minore di (epsilon) " << epsilon << "? " << std::endl;
         inliers++;
         //std::cout << "Aumento inliers a " << inliers << std::endl;
         cii.push_back(j); //salvo gli indici migliori

       }

//   4) calcolo gli inliers del modello attuale, salvando punti e coordinate immagine corrispondenti
			 if( inliers > bestInliers )
       {
         //std::cout << "Numero di inliers: " << inliers << " , maggiore di " << bestInliers << std::endl;

         if(n == bestIteration)
         {
           inliers_best_points.push_back(points[j]);
					 inliers_best_uv.push_back(uv[j]);

           bestInliers = inliers;
           n = bestIteration;
         }
         else
         {
           inliers_best_points.clear();
					 inliers_best_uv.clear();

           for(int jj = 0 ; jj < cii.size() ; jj++)
           {
             inliers_best_points.push_back(points[cii[jj]]);
						 inliers_best_uv.push_back(uv[cii[jj]]);

           }

           bestInliers = inliers;
           n = bestIteration;

         }
			 }

		 }

	 } //fine for ransac

	 std::cout << "inliers_best_points size: " << inliers_best_points.size() << '\n';
//	 std::cout << "inliers_best_uv size: " << inliers_best_uv << '\n';


}

int main(int argc, char **argv)
{

	//////////////////////////////////////////////////////////////////
	// Parse argument list:
	//
	// DO NOT TOUCH
	if (argc != 3)
	{
		std::cerr << "Usage ./prova <left_image_filename> <dsi_filename" << std::endl;
		return 0;
	}

	//opening left file
	std::cout<<"Opening "<<argv[1]<<std::endl;
	cv::Mat left_image = cv::imread(argv[1], CV_8UC1);
	if(left_image.empty())
	{
		std::cout<<"Unable to open "<<argv[1]<<std::endl;
		return 1;
	}
	//////////////////////////////////////////////////////////////////


	//////////////////////////////////////////////////////////////////
	// Lettura delle disparita'
	//
	// DO NOT TOUCH
	cv::Mat imgDisparity16U(left_image.rows, left_image.cols, CV_16U, cv::Scalar(0));
	cv::Mat imgDisparityF32(left_image.rows, left_image.cols, CV_32FC1, cv::Scalar(0));

	// Leggiamo la dsi gia' PRECALCOLATA da file
	std::ifstream dsifile(argv[2], std::ifstream::binary);
	if(!dsifile.is_open())
	{
		std::cout<<"Unable to open "<<argv[2]<<std::endl;
		return 1;
	}
	dsifile.seekg(0, std::ios::beg);
	dsifile.read((char *)imgDisparity16U.data,imgDisparity16U.rows*imgDisparity16U.cols*2);
	dsifile.close();

	imgDisparity16U.convertTo(imgDisparityF32, CV_32FC1);
	imgDisparityF32/=16.0;
	//////////////////////////////////////////////////////////////////



	/////////////////////////////////////////////////////////////////////
	//	EX1
	//
	//	 Calcolare le coordinate 3D x,y,z per ogni pixel, nota la disparita'
	//
	//	 Si vedano le corrispondenti formule per il calcolo (riga, colonna, disparita') -> (x,y,z)
	//
	//	 Utilizzare i parametri di calibrazione forniti
	//
	//	 I valori di disparita' sono contenuti nell'immagine imgDisparityF32

	//vettore dei punti 3D calcolati a partire disparita'
	std::vector<cv::Point3f> points;
	//vettore delle corrispondenti righe,colonne
	std::vector<cv::Point2i> rc;

	compute3Dpoints(imgDisparityF32, points,  rc);
	/////////////////////////////////////////////////////////////////////



	/////////////////////////////////////////////////////////////////////
	//	 EX. 2
	//
	//	 Calcolare con RANSAC il piano che meglio modella i punti forniti
	//
	//	 Si tratta di implementare un plane fitting con RANSAC.
	//

	// vettore degli inliers del modello migliore
	std::vector<cv::Point3f> inliers_best;

	//vettore delle coordinate (r,c) degli inliers migliori
	std::vector<cv::Point2i> inliers_best_rc;

	computePlane(points, rc, inliers_best, inliers_best_rc);

	/*
	 * Creare un'immagine formata dai soli pixel inliers
	 *
	 * Nella parte di RANSAC precedente dovro' quindi calcolare, oltre ai punti 3D inliers, anche le loro coordinate riga colonna corrispondenti
	 *
	 * Salvare queste (r,c) nel vettore inliers_best_rc ed utilizzarlo adesso per scrivere l'immagine out con i soli pixel inliers
	 */

	//immagine di uscita che conterra' i soli pixel inliers
	cv::Mat out(left_image.rows, left_image.cols, CV_8UC1, cv::Scalar(0));
	/*
	 * YOUR CODE HERE
	 *
	 * Costruzione immagine di soli inliers
	 *
	 * Si tratta di copia gli inliers dentro out
	 */
	/////////////////////////////////////////////////////////////////////
	//prova 1
	std::cout << "inliers_best_uv size: " << inliers_best_rc << '\n';


	for(int r = 0; r< out.rows; r++)
	{
		for(int c = 0; c< out.cols; c++)
		{
			for(int i = 0; i < inliers_best_rc.size(); i++)
			{
				if(r == inliers_best_rc[i].x && c == inliers_best_rc[i].y)
				{
					std::cout << "inliers_best_rc[i] : " << inliers_best_rc[i] << '\n';
					out.at<float>(r,c) = left_image.at<float>(r,c);
				}

				//std::cout << "r: " << r << ", c: " << c <<'\n';
				//std::cout << left_image.at<float>(r,c) << '\n';
				//out.at<float>(r,c) = left_image.at<float>(r,c);
			}

		}
	}

//prova 2
/*
	int r,c;
	for(int i = 0; i < inliers_best_rc.size(); i++)
	{
		std::cout << "inliers_best_rc[i] : " << inliers_best_rc[i] << '\n';

		//int r,c;
		r = inliers_best_rc[i].x;
		c = inliers_best_rc[i].y;

		std::cout << "r: " << r << ", c: " << c <<'\n';
		std::cout << left_image.at<float>(r,c) << '\n';
		//out.at<float>(r,c) = left_image.at<float>(r,c);
	}
*/
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	//display images
	//
	// DO NOT TOUCH
#ifdef USE_OPENCVVIZ
	cv::viz::Viz3d win("3D view");
	win.setWindowSize(cv::Size(800, 600));

	cv::Mat points_mat;
	PointsToMat(points, points_mat);
	win.showWidget("cloud", cv::viz::WCloud(points_mat));

	std::cout << "Press q to exit" << std::endl;
	win.spin();
#endif

	cv::namedWindow("left image", cv::WINDOW_NORMAL);
	cv::imshow("left image", left_image);

	cv::namedWindow("left image out", cv::WINDOW_NORMAL);
	cv::imshow("left image out", out);

	//wait for key
	cv::waitKey();
	///////////////////////////////////////////////////////////////////////////////////////////////////////

	return 0;
}
